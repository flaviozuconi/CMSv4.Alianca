$(document).ready(function () {
    function isIE() {
        var myNav = navigator.userAgent.toLowerCase();
        return (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : false;
    }
    if (isIE() && isIE() <= 9) {
        $('.in-space-infographic').addClass('ie');
        $('.download').fadeOut();
    }

    /*  imgs = $('.download img').length;
      $('.download img').load(function(){
        imgs--;
        console.log(imgs);
    
        if(imgs == 1) {
          console.log('fim');
          $('.download').fadeOut();
        }
      });*/

    //inicia a animacao
    $('.btn-play').on('click', function () {
        $('.in-space-infographic').removeClass('replay');
        runAnimation();
    });

    //limpa todos os passos para comerçar novamente
    $('.btn-replay').click(function () {
        $('.in-space-infographic .btn-play').remove()
        stopAnimation();//para de rodar a funcao de pular os passos
        $('.title-in-space').attr('data-count', '3');//seta o valor do contador pra tres novamente
        //$('.in-space-infographic').removeClass('replay');//restaura o estado original do play
        $('.in-space-infographic').animate({
            height: 400
        }, 500, function () {
            runAnimation();//restaura o estado original do play
            $('.in-space-infographic').removeAttr('style');
        })



        $('.in-space-infographic').removeClass(function (index, css) {
            return (css.match(/(^|\s)step-\S+/g) || []).join(''); //remove todas as classes de passos
        });
        $('.in-space-infographic').removeClass('running').addClass('step-0 replay').attr('data-step', 0);
    });

    /*$(document).keydown(function(e){
      var key = e.keyCode;
  
      if (key == 37) { //left arrow
        prevStep();
      } else if (key == 39 || key == 32) { //right arrow or spacebar
        nextStep();
      }
    });*/

    /*$(".in-space-infographic > *").on('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(e) {
      console.log('end');
    });*/

    //Se for mobile
    var respWdt = 768;
    if (isMobile.phone || respWdt < 768) {
        $('.in-space--infographic').hide();
        //Chama carrossel substituto
        // $('.space-carousel').owlCarousel({
        //   loop:false,
        //   margin:0,
        //   nav:true,
        //   dots:true,
        //   items:1
        // });
        // $('#video').on('click', function () {
        //   MediaElement('playermap', { success: function (me) {
        //       me.play();
        //   });
        // });
        $(window).scroll(function () {
            /* Check the location of each desired element */
            $('.hideme').each(function (i) {
                var bottom_of_object = $(this).offset().top + $(this).outerHeight();
                var bottom_of_window = $(window).scrollTop() + $(window).height();
                /* If the object is completely visible in the window, fade it it */
                if (bottom_of_window > bottom_of_object) {
                    $(this).animate({ 'opacity': '1' }, 500);
                }
            });
        });
    }
    else {
        $(window).scroll(function () {
            /* Check the location of each desired element */
            $('.ballons-open').each(function (i) {
                var bottom_of_object = $(this).offset().top + $(this).outerHeight() - 300;
                var bottom_of_window = $(window).scrollTop() + $(window).height();
                /* If the object is completely visible in the window, fade it it */
                if (bottom_of_window > bottom_of_object) {
                    ballonsPage();
                }
            });
        });
    }
});

function countDown() {
    nCount = setInterval(nCountn, 1000);
}
function nCountn() {
    count = $('.title-in-space').attr('data-count');
    $('.title-in-space').attr('data-count', count - 1);
    console.log('count');

    if (count == 1) {
        clearInterval(nCount);
        nCount = undefined;
    }
}

function runAnimation() {
    takeSteps = setInterval(nextStep, 499);
}
function stopAnimation() {
    if (takeSteps != undefined) {
        clearInterval(takeSteps);
        takeSteps = undefined;
    }
}

function nextStep() {
    var inSpace = $('.in-space-infographic');

    if (!(inSpace.hasClass('running'))) {
        step = parseInt(inSpace.attr('data-step'));

        if (step < 8) {
            stepCount = step + 1;
            inSpace.addClass('step-' + stepCount + ' running').attr('data-step', stepCount);
        } else {
            stopAnimation(); //para de rodar a funcao de pular os passos
        }

        //bloqueia o avanco da animacao de acordo com o tempo de cada passo
        if (stepCount == 1) {
            unRun(1.5);
        } else if (stepCount == 2) {
            unRun(10);
        } else if (stepCount == 3) {
            unRun(10);
        } else if (stepCount == 4) {
            unRun(23);
            setTimeout(countDown, 3000);
        } else if (stepCount == 5) {
            unRun(4);
        } else if (stepCount == 6) {
            unRun(15);
        } else if (stepCount == 7) {
            unRun(5);
        } else if (stepCount == 8) {
            unRun(5);
        } else {
            unRun(5);
        }
    }
}

function prevStep() {
    var inSpace = $('.in-space-infographic');

    if (!(inSpace.hasClass('running'))) {
        step = parseInt(inSpace.attr('data-step'));

        if (step > 0) {
            inSpace.removeClass('step-' + stepCount);
            stepCount = step - 1;
            inSpace.attr('data-step', stepCount);
        }
    }
}

function unRun(waitTime) {
    waitTime = waitTime * 1000;
    setTimeout(function () {
        $('.in-space-infographic').removeClass('running');
    }, waitTime);
}


function ballonsPage() {
    var pageStep = $('[data-pagestep]');
    var stepSize = pageStep.length;
    var animateTime = 500;
    //console.log(pageStep.length);

    var i = 0;
    theLoop(stepSize, i);

    function theLoop(stepSize, i) {
        setTimeout(function () {
            $('.mis--presentation').find("[data-pagestep='" + i + "']").addClass('mis-animating').children().addClass('mis-animating');

            i++;
            if (i <= stepSize) {    // If i > 0, keep going
                theLoop(stepSize, i); // Call the loop again, and pass it the current value of i
            }
        }, animateTime);
    }
}

jQuery(window).load(function () {
    $('.download').fadeOut();
});