$(document).ready(function () {
    if ($('.icheck').length > 0) {
        $('.icheck').iCheck({
            checkboxClass: 'icheckbox_minimal',
            radioClass: 'iradio_minimal',
            increaseArea: '20%' // optional
        });
    }
    //chama paginacao
    showList();

    $(document).on('lazybeforesizes', function (e) {
        //use width of parent node instead of the image width itself
        e.target.width = $(e.target).closest(':not(picture)').innerWidth() || e.target.width;

        console.log(e, 'asd');
    });

    //vars gerais
    var respWdt = 768;
    var documentWid = $(document).width();
    documentHei = $(document).height();
    wdwWid = $(window).width();
    wdwHei = $(window).height();

    //Menu Global
    headMainWid = $('.header-main .container').outerWidth();
    headMainHei = $('.main-header').outerHeight();
    headMenuGlobal = $('.header-menu-global').outerHeight();
    headSumHei = headMainHei + headMenuGlobal;
    headerHei = $('.header').outerHeight();

    //abre o campo de pesquisa resoluções < 768px
    $('.search-header .icon-search').click(function () {
        $('.search-header').addClass('open');
        $('.search-header .form-control').focus();
    });
    //fecha o campo de pesquisa
    $('.search-header .search-submit').click(function () {
        $('.search-header').removeClass('open');
    });
    removeFocus('.search-header .form-control', '.search-header');
    removeFocus('.nav-toggle', '.search-header');

    //rola a pagina para o topo
    $('.go-top').click(function () {
        $('html, body').animate({ scrollLeft: 0 }, 'slow');
        return false;
    });

    if ($('.affix').length > 0) {
        $('.affix a').on('click', function () {
            $('.affix li').removeClass('active');
            $(this).parents('li').addClass('active');
        });
    }

    //Atribue modal para lighbox
    $(document).delegate('*[data-toggle="lightbox"]', 'click', function (event) {
        event.preventDefault();
        $(this).ekkoLightbox();
    });

    //Liga os Popovers
    $('[data-toggle="popover"]').popover();

    //adiciona classe no elemento pai do menu principal quando o filho está ativo
    $('.navbar .dropdown').on('shown.bs.dropdown', function () {
        $(this).parents('.navbar').addClass('active');
    });
    //remove classe no elemento pai do menu principal quando o filho está ativo
    $('.navbar .dropdown').on('hidden.bs.dropdown', function () {
        $(this).parents('.navbar').removeClass('active');
    });

    //adiciona classe no titulo quando existe select ano
    $(".content--header .select-top").each(function () {
        $(".section-title-sub").addClass("title-year-select")
    });

    /*  //para correções de posicionamento do link
      $('.nav-justified>li').click(function () {
        var getLink = $(this).children('a');
        var link = getLink.attr('href');

        if (link != undefined) {
          window.location.href = link;
        }
      });*/

    //Selectboxit
    if ($('.selectit').length > 0) {
        $('.selectit').selectBoxIt({
            autoWidth: false,
            downArrowIcon: 'glyphicon glyphicon-chevron-down',
            copyClasses: 'container'
        });
    }
    //Selectpicker
    if ($('.selectpicker').length > 0) {
        $('.selectpicker').selectpicker();
    }

    //plugins para calendário
    $('.calendar-datepicker').datepicker({
        showOtherMonths: true,
        selectOtherMonths: true,
        onSelect: function (selectedDate) {
            //callback de seleção de data
            alert(selectedDate);
        }
    });

    //scroll eventos do calendário
    $('.calendar-events').mCustomScrollbar({
        scrollInertia: 300
    });

    //scroll social box
    $('.social-scroll').mCustomScrollbar({
        scrollInertia: 300,
        theme: 'dark-thick'
    });

    $('.description').mCustomScrollbar({
        scrollInertia: 300,
        mouseWheel: true,
        mouseWheel: {
            enable: true,
            scrollAmount: 20
        },
        theme: 'dark-thick'
    });

    //tooltip para botões da página resultado--interna
    $('[data-toggle="tooltip"]').tooltip()

    //abre o menu com mouse over se a tela for maior que 768px
    if ($(window).width() > 767) {
        $('.header li.dropdown').bind({
            //$(this).find('[data-toggle="dropdown"]').dropdown('toggle');
            //$('.header .main-menu .dropdown').toggleClass('open');
            mouseenter: function () {
                $(document).find('.dropdown').removeClass('open');
                $(this).addClass('open');
            },
            click: function () {
                $(document).find('.dropdown').removeClass('open');
                $(this).addClass('open');
            },
            mouseleave: function () {
                $(this).removeClass('open');
            }
        });
        //menuSupPosition('.main-menu .dropdown', '.header .main-menu');
    }

    $('.gotop').click(function () {
        $('html,body').animate({ scrollTop: 0 }, 900);
        return false;
    });

    var homecheck = $('[data-home]');
    if (homecheck.length > 0) {
        $('footer').css('margin-top', '0');
    }

    //Owl Carousel Todos
    // carousel historia
    if ($('.owl-interna').length > 0) {
        $(".owl-interna").owlCarousel({
            stagePadding: 100,
            items: 1,
            loop: false,
            center: true,
            merge: true,
            onInitialized: function () {
                var header = $('.owl-interna .owl-controls .owl-dot'); //cabeçalho que chama os itens
                var items = this.items();
                for (var i = 0; i < items.length; i++) {
                    var div = items[i].find('[data-ano]'); //procura por elemento com atributo data-ano
                    if (div && div.length > 0) {
                        var divAno = $('<div />');

                        divAno.css("color", $(header[i]).find('span').css('background-color'));
                        divAno.css('position', 'absolute');
                        divAno.css('top', '-25px');
                        divAno.css('left', '18px');
                        divAno.css('font-weight', 'bold');
                        divAno.html(div.data('ano'));

                        $(header[i]).append(divAno); //adiciona uma div na posicao 'i' do header com o valor presente em data-ano
                    }
                }
            }
        });
    }

    // carousel inovação
    if ($('.owl-inovacao').length > 0) {
        $('.owl-inovacao').owlCarousel({
            items: 1,
            loop: false,
            center: true,
            merge: true
        });
    }

    // galleria 1 foto
    if ($('.carousel-gallery .carousel-photo').length > 0) {
        $('.carousel-gallery .carousel-photo').owlCarousel({
            items: 1,
            loop: false,
            center: false,
            nav: true,
            lazyLoad: true,
            navText: [
              '<div class="icon icon-chevron-left"></div>',
              '<div class="icon icon-chevron-right"></div>'
            ]
        });
    }

    var heights = $('.principios_governanca .nav li').map(function () {
        return $(this).height();
    }).get(),

    maxHeight = Math.max.apply(null, heights);

    $('.principios_governanca .nav li').height(maxHeight);

    $('.principios_governanca .nav li p').each(function () {
        var hh = $(this).height();
        $(this).attr('data-height', hh).height(0);
    });

    $('.principios_governanca .nav li').mouseenter(function () {
        var pp = $(this).find('p');
        var ph = pp.attr('data-height');
        var nh = ph + 'px';

        pp.animate({
            height: nh
        }, 300);
        //console.log(ph, nh)
    });

    $('.principios_governanca .nav li').mouseleave(function () {
        var pp = $(this).find('p');
        pp.animate({
            height: 0
        }, 300);
    });



    //Contagem dos itens do carousel
    var countCar = $('.carousel-counter');
    countCar.each(function () {
        var lengNews = $(this).parent().find('.carousel-inner').children().length;
        var lengNewsSoma = lengNews - 1;
        $(this).find('.counter-target').html('<b>1</b>' + ' / ' + lengNews);
    });
    $('.carousel-control').on('click', function () {
        $(this).parents('.carousel').on('slid.bs.carousel', function () {
            slideFrom = $(this).find('.active').index() + 1;
            slideTo = $(this).find('.active').index() + 3;
            $(this).find('.counter-target b').empty().text(slideFrom) + 2;
        });
    });

    owl = $(".owl-carousel");

    //step carousel
    var owlTiles = $('.carousel-tiles--container');

    owlTiles.on('initialized.owl.carousel', function (event) {
        var $itemsWrap = owlTiles.find("div.itemsWrap"); // or use Owl's .owl-stage class
        var items = event.item.count;
        var $owlControls = $('div.owl-controls');
        items <= 1 ? $owlControls.hide() : $owlControls.show();
    });
    owlTiles.owlCarousel({
        items: 1,
        responsive: true,
        dots: false,
        nav: true,
        navText: [
          '<div class="icon icon-chevron-left"></div>',
          '<div class="icon icon-chevron-right"></div>'
        ]
    });

    //gallery-step
    var owlStep = $('.gallery-step--container');
    owlStep.owlCarousel({
        margin: 20,
        pagination: false,
        dots: false,
        nav: true,
        navText: [
          '<div class="icon icon-chevron-left"></div>',
          '<div class="icon icon-chevron-right"></div>'
        ],
        responsive: {
            0: {
                items: 1,
            },
            768: {
                items: 2,
            },
            1199: {
                items: 3,
            }
        }
    });

    //carousel-gallery
    owlGalleryTarget = $('.carousel-gallery');

    if (owlGalleryTarget.length > 0) {
        owlGallery = owlGalleryTarget.find('.owl-carousel');
        var sizeGallery = $('.carousel-gallery .owl-carousel').find('.item').length;

        owlGallery.owlCarousel({
            pagination: false,
            mouseDrag: false,
            nav: true,
            navText: [
              '<div class="icon icon-chevron-left"></div>',
              '<div class="icon icon-chevron-right"></div>'
            ],
            items: 1
        });

        owlIndicators = $('.carousel-indicators');


        $(owlIndicators).each(function (index, el) {
            var owlIndicatorsWidth = $(this).outerWidth();
            console.log(owlIndicatorsWidth);

            var indWid = owlIndicatorsWidth;
            var indItems;

            if (indWid > 0 && indWid < 400) {
                indItems = 3;
            } else if (indWid >= 400 && indWid < 750) {
                indItems = 5;
            } else if (indWid >= 750 && indWid < 992) {
                indItems = 8;
            } else if (indWid >= 992 && indWid < 1200) {
                indItems = 10;
            } else if (indWid >= 1200) {
                indItems = 12;
            }

            $(this).owlCarousel({
                responsive: false,
                items: indItems,
                nav: true,
                dots: false,
                //center: true,
                navText: [
                  '<div class="icon icon-chevron-left"></div>',
                  '<div class="icon icon-chevron-right"></div>'
                ],
                onInitialize: gallereyAbaShow,
                onInitialized: gallereyAbaShowed
            }).promise().done(function () {
                //depois de carregado faz algo
            });

            function gallereyAbaShow() {
                $('.gallery--header-icons').find('.tab-pane').toggleClass('loading');
            }

            function gallereyAbaShowed() {
                $(owlIndicators).each(function (index, el) {
                    var owlIndicadorsEleWid = $(this).find('.owl-item').outerWidth();
                    //var owlCar = e.target;
                    // var element   = event.target;
                    // console.log(event, element, $(this));
                    // $(element).css('border', '2px solid yellow');
                    // $(this).addClass('classe-');
                    $('.gallery--header-icons').find('.tab-pane').toggleClass('loading');
                    var indInternalWid = $(this).find('.owl-stage').outerWidth();
                    var indExternalWid = $(this).find('.owl-stage-outer').outerWidth();
                    var itemCount = $(this).find('.owl-stage .owl-item').length - 1;

                    $(this).find('.owl-prev').addClass('inactive');

                    //console.log('carreguei', indInternalWid, indExternalWid, itemCount, owlIndicadorsEleWid, owlIndicadorsEleWid*itemCount);

                    if (owlIndicadorsEleWid * itemCount < indExternalWid) {
                        $(this).find('.owl-nav').hide();
                    }
                });
            }

        });



        owlIndicators.on('changed.owl.carousel', function (e) {
            //active nos thumbs
        });


        owlGallery.on('dragged.owl.carousel', function (e) {
            //active nos thumbs
            var owlCar = e.target;
            var owlItem = e.item.index;
            var owlParent = $(owlCar).parent();
            //console.log(owlCar, owlItem, owlParent);
            owlParent.find('.carousel-indicators li').removeClass('active').promise().done(function () {
                //owlParent.parent().find('.carousel-indicators .owl-item').eq(owlItem).children('li').addClass('active');
            });
            //$(owlIndicators).trigger('to.owl.carousel', [owlItem]);
            //console.log(owlIndicators);
            //$(owlIndicatorsMultimidia).trigger('to.owl.carousel', [owlItem]);
        });

        //paginação do carousel (thumbs)
        owlIndicators.find('li').click(function (e) {
            e.preventDefault();
            var owlTarget = $(this).attr('data-target');
            var owlCarEle = $(owlTarget).children('.owl-carousel:first');
            $(this).closest('.owl-stage').find('.owl-item').removeClass('active').children('li').removeClass('active');
            $(this).addClass('active');

            var owlGoTo = $(this).parent().index();

            owlCarEle.trigger('to.owl.carousel', [owlGoTo]);

            //return false;
        });

        //Carousel Galleria com video --> noticia-galeria.html
        owlGallery.on('changed.owl.carousel', function (e) {
            var pathVideo = $('.carousel-gallery').find('.owl-carousel:first .video-gallery');
            pathVideo.each(function (index, el) {
                var video = $(this).data('youtube');
                $(this).attr('src', '');
                $(this).attr('src', video);
            });
        });

    }


    //carousel-gallery
    owlEvent = $('.carousel-event .owl-carousel');
    owlEvent.owlCarousel({
        pagination: false,
        nav: true,
        dots: false,
        items: 1,
        navText: [
          '<div class="icon icon-chevron-left"></div>',
          '<div class="icon icon-chevron-right"></div>'
        ]
    });

    owlIndicatorsMultimidia = $('.carousel-gallery__multimidia .carousel-indicators__multimidia');

    owlIndicatorsMultimidia.owlCarousel({
        autoplay: false,
        items: 1,
        autoWidth: true,
        nav: true,
        loop: true,
        center: true,
        //center: true,
        navText: [
          '<div class="icon icon-chevron-left"></div>',
          '<div class="icon icon-chevron-right"></div>'
        ],
        onInitialize: gallereyAbaShow,
        onInitialized: gallereyAbaShow
    });

    function gallereyAbaShow() {
        $('.gallery--header-icons').find('.tab-pane').toggleClass('loading');
    }



    owlIndicatorsMultimidia.find('li').click(function (e) {
        var owlCarousel = $($(this).attr('data-target')).children('.owl-carousel');
        var _this = $(this);

        if ($(this).parent().hasClass('owl-item')) {
            var owlGoTo = $(this).parent().index();
            $(this).parents('.owl-stage').find('.active').removeClass('active').promise().done(function () {
                _this.addClass('active');
            });
            //console.log('esse')
        }
        else {
            var owlGoTo = $(this).index();
            $(this).parent().children('li').removeClass('active').promise().done(function () {
                _this.addClass('active');
            })
        }
        //console.log(owlGoTo);

        $(owlCarousel).trigger('to.owl.carousel', [owlGoTo]);

        return false;
    });


    //carousel-gallery
    owlInfo = $('.carousel-infographic .owl-carousel');
    owlInfo.owlCarousel({
        pagination: false,
        dots: false,
        nav: true,
        items: 1,
        navText: [
          '<div class="icon icon-chevron-left"></div>',
          '<div class="icon icon-chevron-right"></div>'
        ]
    });

    //Carrossel full
    if ($('.owl-carousel--fullbanner > .item').length > 1) {
        $('.owl-carousel--fullbanner').owlCarousel({
            loop: true,
            nav: true,
            items: 1,
            dots: false,
            navContainer: '.banner-full .nav-position',
            navText: [
              '<div class="icon icon-chevron-left"></div>',
              '<div class="icon icon-chevron-right"></div>'
            ]
        });
    }
    //step carousel
    var owlStepC = $('.step-carousel--container');

    if (owlStepC.find('.box-featured').length >= 5 || wdwWid <= respWdt) {
        owlStepC.owlCarousel({
            margin: 20,
            pagination: true,
            responsive: true,
            dots: true,
            navText: [
              '<div class="icon icon-chevron-left"></div>',
              '<div class="icon icon-chevron-right"></div>'
            ],
            responsive: {
                0: {
                    items: 1,
                },
                480: {
                    items: 2,
                },
                768: {
                    items: 3,
                },
                1199: {
                    items: 4,
                }
            }
        }).promise().done(function () {
            $('.step-carousel--container .owl-prev').addClass('inactive')
        });
        //navegação step carousel

        $('.step-carousel--right').click(function () {
            owl.trigger('owl.next');
        });
        $('.step-carousel--left').click(function () {
            owl.trigger('owl.prev');
        });
    }
    else {
        owlStepC.addClass('step-carousel--inactive');
    }

    //Adiciona nav no prev (porque é o estado 0)
    owl.find('.owl-prev').addClass('inactive');

    $('.owl-carousel').not('.clear-inactive').on('changed.owl.carousel', function (e) {
        owlCurrent = $($(this).context);
        var shown = e.page.size;
        var total = e.relatedTarget.items().length;
        var current = e.item.index;
        var remain = total - (shown + current);
        //console.log(shown, total, current, remain);
        if (!remain) {
            owlCurrent.find('.owl-next').addClass('inactive');
        }
        else {
            owlCurrent.find('.owl-next').removeClass('inactive');
        }
        if (current == 0) {
            owlCurrent.find('.owl-prev').addClass('inactive');
        }
        else {
            owlCurrent.find('.owl-prev').removeClass('inactive');
        }
    });

    //Carrossel owl-bullet-bar
    var owlBulletBar = $('.owl-bullet-bar');

    owlBulletBar.owlCarousel({
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 3
            },
            992: {
                items: 5
            }
        },
        items: 5,
        nav: true,
        dots: false,
        navText: ['<span class="glyphicon glyphicon-chevron-left">', '<span class="glyphicon glyphicon-chevron-right">'],
        onInitialize: bulletShow,
        onInitialized: bulletIned
    });

    function bulletShow() {
        $('.bullet-bar--wrapper').find('.tab-pane').toggleClass('loading');
    }

    function bulletIned() {
        bulletShow();
        var idBull = $('.bullet-bar--wrapper .nav li a').attr('href');
        // var hBull = $(idBull).outerHeight();
        e = $(idBull).parents('[data-loading]'); //Define o alvo do loading
        channelingLoad(e); //Chama a função que compõe o loading

        $(idBull).find('.equalizer-inner').unwrap();

        $(idBull).addClass('in');
        //console.log(idBull);

        $(window).load(function () {
            doneLoad(e);
            $('.bullet-bar--wrapper').find('.owl-bullet-bar').equalizer({
                columns: '.thumbnail' // elements inside of the bullet-bar--wrapper
            });
        });
        //console.log(hBull, idBull);
    }

    $('.bullet-bar--wrapper .abas a').on('shown.bs.tab', function (e) {
        $('.bullet-bar--wrapper').find('.owl-bullet-bar').equalizer({
            columns: '.thumbnail' // elements inside of the wrapper
        });
    })
    //Remove o selection nos controls
    $('.nav-position .owl-next, .nav-position .owl-prev').mousedown(function (e) {
        e.preventDefault();
    });

    //Owl Carousel Todos TERMINA
    //Todos os scripts específicos para mobile < 768
    if (isMobile.phone || isMobile.tablet) {
        //Chama Goto TOp
        showGoTop('.gotop');

        //Ativa Swipe
        $(".carousel").on({
            swiperight: function () {
                $(".carousel").carousel('prev');
            },
            swipeleft: function () {
                $(".carousel").carousel('next');
            }
        });

        //funções que se repetem no load e na mudança de orientação do aparelho
        $(window).on({
            orientationchange: function () {
                //quando muda a orientação do celular
                resizeMobile('.navbar-collapse');
                menuRetractable();
            },
            load: function () {
                //só executa no load total da página
            }
        });

        //Monta menu
        mobileMenuBdr();
        floatingTabs('.floating-tabs');

        $('.carousel-tabs').owlCarousel({
            items: 1,
            responsive: true,
            dots: false,
            nav: true,
            navText: [
              '<div class="icon icon-arrow-left"></div>',
              '<div class="icon icon-arrow-right"></div>'
            ]
        });
        //monta aviso no mobile
        avisoMount();
        $('.menu-mobile--calls > .message-box').on('click', function () {
            avisoMount();
        });
    }
        //-- Acaba os específicos para mobile
    else {
        $(document).on('scroll', function () {
            menuTopFunc();
        });
        //Verifica se o menu estoura o screen
        $('.message-box > a').click(function () {
            var scr = scrollizer('.message-box--list');
            scr;
        });
        $('.programas-nav').affix({
            offset: {
                top: 142,
                bottom: 400
            }
        });
    }

    if (!isMobile.phone) {
        menuRetractable();
    }

    $('.main-header > .icon-menu').click(function () {
        $('.header.menu-fixed .main-menu').toggleClass('in').slideDown('slow');
    });

    /*chama o loading*/
    $('[data-loading-action]').click(function (event) {
        e = $(this).parents('[data-loading]'); //Define o alvo do loading
        channelingLoad(e); //Chama a função que compõe o loading

        //Executa função no SetTimeOut - pode substituir por uma outra função AJAX ou algo necessário para a exibição do item.
        //Enquanto ela não for chamada não sumirá o loading e nem exibirá o target (definido pelo DATA-LOADING-TOGGLEIN e pelo DATA-LOADING-TOGGLEOUT)
        setTimeout(function () {
            doneLoad(e); //Remove o loading e chama o resultado
        }, 5000);
    });

    // efeito de abas para patrocínios
    $('.patrociniosTab a').click(function (e) {
        e.preventDefault()
        $(this).tab('show')
    });

    // ajustes de largura para links da navegação interna
    var qtdItens = $(".navegacao-interna li").size();
    var widthItem = 100 / qtdItens;
    $(".navegacao-interna li").css("width", widthItem + "%");

    $('.infographic a').click(function (e) {
        e.preventDefault()
        $(this).tab('show')
    });

    if ($('.braskem-map').length > 0) {
        braskemMap('.braskem-map');
    }

    if ($('[data="count-carousel"]').length > 0) {
        var param1var = querystring('index');
        var positionCarousel = parseInt(querystring('index').toString())

        //console.log(param1var, positionCarousel);

        if (param1var != '') {
            $('[data="count-carousel"]').carousel(positionCarousel);
            $('[data="count-carousel"]').closest('.carousel').find('.carousel-counter b').text(positionCarousel + 1);
        }
    }

    if ($('.secondary-menu .nav-justified .active').length > 0) {
        $('.secondary-menu .toggle-secondary').text($('.secondary-menu .nav-justified .active').text()).append('<span class="icon icon-chevron-bottom" />');
    }

    $(window).on('resize load', function () {
        if ($(window).width() < 767) {
            $('.carousel-especial-boxes').owlCarousel({
                loop: false,
                nav: false,
                responsive: false,
                items: 1
            });

            $('.carousel-tabs').owlCarousel({
                items: 1,
                responsive: true,
                dots: false,
                nav: true,
                navText: [
                '<div class="icon icon-arrow-left"></div>',
                '<div class="icon icon-arrow-right"></div>'
                ]
            });
        } else {
            $('.carousel-especial-boxes, .carousel-tabs').trigger('destroy.owl.carousel');
        }

        if ($(window).width() < 992) {
            $('.carousel-tiles--container').trigger('destroy.owl.carousel');
        }
    });

    if ($('.info-sustentabilidade').length > 0) {
        $.getScript('/portal/Braskem/js/info-sustentabilidade.js');
        $('head').append('<link rel="stylesheet" href="/portal/Braskem/css/info-sustentabilidade.css">');
    }

    $('.eqlzr').equalizer({
        columns: '> div' // elements inside of the wrapper
    });

    $('.content-info').equalizer({
        columns: '.item' // elements inside of the wrapper
    });

    $('.infographic-stationary .row').equalizer({
        columns: '.thumbnail' // elements inside of the wrapper
    });

    $('.bullet-bar--wrapper .abas a').on('shown.bs.tab', function (e) {
        $('.bullet-bar--wrapper').find('.infographic-stationary').equalizer({
            columns: '.thumbnail' // elements inside of the wrapper
        });
    });

    resizeFigure($('.list-block-img figure'));

    var maxHeight = Math.max.apply(null, $('.jovens-listagem .info').map(function () {
        return $(this).outerHeight();
    }).get());

    if (wdwWid > 479 && wdwWid < 768) {
        $('.jovens-listagem .info').outerHeight(maxHeight);
    }

    function carouselInovacaoImg() { //separado em funcao pois existe muitas dependencias para controle do carousel
        $('.owl-controller li').click(function () {
            owlPos = $(this).index();
            owlCar = $(this).parent().siblings('.owl-carousel');
            owlCar.trigger('to.owl.carousel', [owlPos]);
        });

        $('.owl-controller li').each(function () {
            owlCateg = $(this).attr('data-category');
            $(this).addClass(owlCateg);

            owlCPos = $(this).index();
            //console.log(owlCPos);
            $(this).parent().siblings('.owl-carousel').find('.item').eq(owlCPos).addClass(owlCateg);
        });

        //Carrossel teste
        carouselInovacaoImg = $('.owl-carousel--inovacao-img');
        carouselInovacaoImg.owlCarousel({
            items: 1,
            loop: true
        });

        carouselInovacaoImg.on('changed.owl.carousel', function (e) {
            owlActive = e.item.index - 1;
            carouselInovacaoImg.parent().find('.owl-controller li').removeClass('active');
            carouselInovacaoImg.parent().find('.owl-controller li').eq(owlActive).addClass('active');
        });
    };

    carouselInovacaoImg();

    // $('.link-a').click(function() {
    //     if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
    //       var target = $(this.hash);
    //       target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
    //       if (target.length) {
    //         $('html,body').animate({
    //           scrollTop: target.offset().top
    //         }, 1000);
    //         return false;
    //       }
    //     }
    // });

    if ($('.atletismo-timeline-nav').length > 0) {
        //Utilizado para fazer o scroll/anchor na molecula mol-infographic-linho-do-tempo
        var navListItems = $(".atletismo-timeline-nav").find("li");
        var voltarParaTopo = $(".atletismo-timeline-voltar-para");
        var navContainer = $(".atletismo-timeline-nav-container");
        var boxItems = $(".timeline-item-container");
        var scrollValues = [];
        var controller = new ScrollMagic.Controller({ globalSceneOptions: { duration: 100 } });

        var timeoutScroll;

        $(voltarParaTopo).on("click", function () {
            $("html,body").animate({
                scrollTop: navContainer.offset().top - 5
            }, 750);
        });

        $(boxItems).each(function () {
            var thisScene = new ScrollMagic.Scene({ triggerElement: this }).setClassToggle(this, "show-anim").addTo(controller);
            thisScene.on("start", function () {
                thisScene.removeClassToggle();
            });
        });

        $(window).on("scroll", function () {
            if (timeoutScroll) {
                clearTimeout(timeoutScroll);
            }
            timeoutScroll = setTimeout(scrollEvent, 150);
        });

        function scrollEvent() {
            ((navContainer.offset().top) < $(window).scrollTop()) ? voltarParaTopo.addClass("show-button") : voltarParaTopo.removeClass("show-button");
        }

        $(navListItems).on('click', function () {
            var thisIndex = $(this).index();
            var scrollToElement = $('#atletismo-timeline' + (thisIndex + 1));

            $('html,body').animate({
                scrollTop: scrollToElement.offset().top
            }, 750);
        });
    }

    $('.item').on('click', function () {
        var dataTarget = $(this).data('target');

        $('.desc-item').fadeOut('fast').promise().done(function () {
            $('[data-name=' + dataTarget + ']').fadeIn('fast');
        })
        //console.log(dataTarget)
    });

    $('.programa-etapa').on('click', function () {
        $('.programa-etapa').removeClass('active');
        $(this).addClass('active');
    });

    if ($(window).width() > respWdt) {
        // $('.programas-nav').affix({
        //     offset: {
        //         top: 142,
        //         bottom: 400
        //     }
        // });
    };

    $('.programas-nav').on('affix-top.bs.affix', function () {
        var colSize = $('.programas-nav').closest('[class^="col-"]').width();
        $('.programas-nav').width(colSize);
    });

    $('.faq-question').on('click', function () {

        var answer = $(this).siblings('.faq-answer');

        if (!answer.hasClass('in')) {

            answer.addClass('in');

            answer.slideToggle(function () {
                $(this).toggleClass('opened');
                $(this).removeClass('in');
            });
        }
        if (answer.hasClass('opened')) {
            $(this).parents('.faq').removeClass('faq-opened');
        }
        else {
            answer.parents('.faq').addClass('faq-opened');
        }
    });
    $('.faq-answer.opened').parent().addClass('faq-opened');

    if ($('.audio-player').length > 0) {
        $('.audio-player').mediaelementplayer({
            defaultAudioWidth: '100%',
        });
    }

    $('.catalogo--categorias .icon').click(function () {
        $('.catalogo--categorias .icon').removeClass('active');
        $(this).addClass('active');
    });

    $('.catalogo--lista-familias li').click(function () {
        $('.catalogo--lista-familias li').removeClass('active');
        $(this).addClass('active');
    });


    //showingElement('[data-showing]');

    if (wdwWid > 991 && wdwWid < 1200) {
        caracCounter(90);
    }

    if (wdwWid > 1199) {
        caracCounter(110);
    }

    var diffTop = 20;
    $('a.smooth[href*="#"]:not([href="#"])').click(function () {
        if ($('header.header').hasClass('menu-fixed')) {
            diffTop = 100;
        } else {
            diffTop = 100 //20
        }
        if ($(window).width() < respWdt + 100) {
            diffTop = 20
        };
        //console.log(diffTop);
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html, body').animate({
                    scrollTop: target.offset().top - diffTop
                }, 1000);
                return false;
            }
        }
    });


    equalizer();

    // controle de visualiação de abas de voluntários
    $('.programas-voluntariosJQ .footer-item .btn').on('click', function () {
        var ident = $(this).attr('data-href');

        $('html,body').animate({
            scrollTop: $('.box--programas-voluntarios').offset().top - 100
        },
        1000);

        $('.programas-voluntarios__status').css('display', 'none').removeClass('active');
        $(ident).fadeIn('slow').addClass('active');
        scrollTabIcon();
    });

    $('.closeJQ').on('click', function () {
        $(this).parents('.programas-voluntarios__status').fadeOut('slow').removeClass('active');
        return false;
    })

    $('.programas-voluntarios__status .tab-status>li').on('shown.bs.tab', function () {
        tabActive = $('.programas-voluntarios__status.active .tab-pane.active .tab-icons .nav-tabs .active').index();
        scrollTabIcon();
    });

    /*link dentro de aba*/
    $('.tab-status .link').click(function () {
        link = $(this).data('href');
        window.open(link, '_blank');
    });

}); //fecha jquery


function scrollTabIcon() {
    tabActive = $('.programas-voluntarios__status.active .tab-pane.active .tab-icons .nav-tabs .active').index();
    iconTab = $('.programas-voluntarios__status.active .tab-pane.active .tab-icons .nav-tabs');

    if (tabActive > 2) {
        iconTab.scrollLeft(1000);
    } else {
        iconTab.scrollLeft(0);
    }
}

/*EQUALIZER*/
function equalizer() {

    var eqHeights = $(".equalizer .item").map(function () {
        return $(this).height();
    }).get(),

    eqMaxHeight = Math.max.apply(null, eqHeights);
    console.log(eqMaxHeight);
    $('.equalizer .item').height(eqMaxHeight);
}


/*DEIXAR A FIGURE QUADRADA*/
function resizeFigure(boxFigure) {

    var figWdt = boxFigure.width();

    boxFigure.height(figWdt);
}

/*LIMITAR CARACTER E INSERIR "..." NO FINAL DO TEXTO*/
function caracCounter(caracNumber) {

    $(".jovens-listagem .info p").text(function (index, currentText) {
        var txt = $(this).text().length;

        if (txt > 100) {
            return currentText.substr(0, caracNumber) + '...';
        }
    });
}

function menuRetractable() {
    var resetMenu = $('#main-menu-collapse .recipiente').html();

    //reset menu
    $('#main-menu-collapse').css('width', 'auto');
    $('#main-menu-collapse .recipiente').remove();
    $('#main-menu-collapse').append("<div class='recipiente'>" + resetMenu + "</div>");

    var brandHeader = parseInt($('.brand-header').outerWidth());
    wdwWid = parseInt($(document).outerWidth())
    //console.log(wdwWid);
    if (wdwWid >= 786 && wdwWid <= 848) {
        var searchField = 340;
        //alert();
    } else {
        var searchField = 340;
    }
    var messageBox = parseInt($('.message-box').outerWidth());
    var languagesBox = parseInt($('.languages').closest('.nav').outerWidth());
    var internalMarginMenu = 40; //tamanho da margin interna do menu 15+15 (com +10 de margin do inline-block)
    var btnMenuRecons = 50;

    //console.log(brandHeader, searchField, messageBox)

    var areaHeader = parseInt($('.main-header').width()); // Area total ocupada pela Header
    var areaOcupada = brandHeader + searchField + messageBox + languagesBox + internalMarginMenu + btnMenuRecons; // Largura total ocupada pelos objetos / 750 - 40 é o valor

    var widthMainMenu = parseInt($('#main-menu-collapse .recipiente').outerWidth()); // Largura do menu principal
    var areaLivre = areaHeader - areaOcupada - btnMenuRecons; // Área livre que pode ser usada para armazenar os itens do menu
    var qtdItens = $('#main-menu-collapse ul li').length; // Quantidade de itens cadastrados no menu
    //console.log('virou');

    //console.log(areaOcupada, areaLivre);

    if (areaLivre < widthMainMenu) {
        arrayLargura = [];

        for (var i = 1; i <= qtdItens; i++) {
            arrayLargura.push($('#main-menu-collapse ul li:nth-child(' + i + ')').width());
        }

        for (var i = 0; i < arrayLargura.length; i++) {
            function sumArray(array) {
                for (
                  var
                    index = 0,              // The iterator
                    length = array.length,  // Cache the array length
                    sum = 0;                // The total amount
                    index < length;         // The "for"-loop condition
                    sum += array[index++]   // Add number on each iteration
                );
                return sum;
            }
            somaArray = [];
            for (var x = 0; x < i; x++) {
                somaArray.push(arrayLargura[x]);
                var resultado = sumArray(somaArray);
                if (resultado > areaLivre) {
                    $('#main-menu-collapse ul li:nth-child(' + x + ')').css('display', 'none');
                }
            }
        }
        // setor que monta o novo menu
        var montarNovoMenu = "";
        $('#main-menu-collapse ul li').each(function () {
            if ($(this).css('display') == 'none') {
                montarNovoMenu += "<li>" + $(this).html() + "</li>";
            }
        });

        visibleItems = $('#main-menu-collapse ul li:visible').length;

        if (visibleItems < qtdItens) {
            //$('.nav-header li.languages').parents('.nav').css('display', 'none');
            $('#main-menu-collapse ul').append('<li> <a id="menucustom" href="#" class="btn btn-sm btn-custom-menu" data-toggle="dropdown"> <span class="glyphicon glyphicon-plus"></span> </a> <span class="glyphicon glyphicon-triangle-top"></span> </li>')
            $('#main-menu-collapse ul li:last-child').append('<ul class="dropdown-menu dropdown-menu--custom" aria-labelledby="menucustom" role="menu">' + montarNovoMenu + '</ul>');

            $('#menucustom').on('click', function (e) {
                if ($('.dropdown-menu--custom').css('display') == 'none') {
                    $('.glyphicon-triangle-top').css('display', 'block');
                } else {
                    $('.glyphicon-triangle-top').css('display', 'none');
                }
                $(document).click(function (e) {
                    $('.glyphicon-triangle-top').css('display', 'none');
                });
            });
        }
    }
}
