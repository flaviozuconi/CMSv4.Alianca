$(document).ready(function () {
    //Selectpicker
    if ($('.selectpicker').length > 0) {
        $('.selectpicker').selectpicker();
    }
    perguntaHeight();
    if ($('[data-chat]').length > 0) {
        chatResize();
    }
    //for mobile
    // Listen for orientation changes
    window.addEventListener('orientationchange', function () {
        // Announce the new orientation number
        //console.log(screen.orientation);
        resetChatResize(function () {
            setTimeout(function () {
                chatResize();
            }, 200);
        });
    }, false);

    // Listen for resize changes
    window.addEventListener('resize', function () {
        // Get screen size (inner/outerWidth, inner/outerHeight)
        var wdwWid = $(window).width();
        var wdwHei = $(window).height();
        //console.log(wdwWid, wdwHei);
        resizeCallback(function () {
            setTimeout(function () {
                chatResize();
            }, 200);
        });
    }, false);
});

$(document).on('click', '.enviadas-msg--expand', function () {
    var msgEnviada = $(this).closest('.enviadas-msg');
    msgEnviada.toggleClass('full');

    if (msgEnviada.hasClass('full')) {
        $(this).html('Fechar mensagem <span class="glyphicon glyphicon-menu-up"></span>');
        var heiActual = $(this).siblings('.enviadas-msg--body').data('height');
        $(this).siblings('.enviadas-msg--body').css('height', heiActual);
    } else {
        $(this).html('Abrir mensagem <span class="glyphicon glyphicon-menu-down"></span>');
        $(this).siblings('.enviadas-msg--body').css('height', '60px');
    }

    //console.log(msgEnviada);
}); //--teste
//chat
function chatResize() {
    var sizeWidEnviadas = $('.panel-enviadas').outerWidth();
    var sizeWidDescricao = $('.chat-descricao').outerWidth();
    var sizeHeiTools = $('.box-type-msg').outerHeight();
    var sizeHeiHeader = $('.main-header__chat').outerHeight();
    var wdwWid = $(window).width();
    var wdwHei = $(window).height();
    var topEleHei = wdwHei - sizeHeiTools - sizeHeiHeader;

    // //teste
    // $('.enviadas-msg--expand').on('click', function () {
    //     var msgEnviada = $(this).closest('.enviadas-msg');
    //     msgEnviada.toggleClass('full');
    //
    //     if (msgEnviada.hasClass('full')) {
    //         $(this).html('Fechar mensagem <span class="glyphicon glyphicon-menu-up"></span>');
    //         var heiActual = $(this).siblings('.enviadas-msg--body').data('height');
    //         $(this).siblings('.enviadas-msg--body').css('height', heiActual);
    //     } else {
    //         $(this).html('Abrir mensagem <span class="glyphicon glyphicon-menu-down"></span>');
    //         $(this).siblings('.enviadas-msg--body').css('height', '60px');
    //     }
    //
    //     //console.log(msgEnviada);
    // }); //--teste

    if ($('[data-type]').data('type') == 'convidado') {
        //Resize para �rea do convidado
        $('html').addClass('chat-general').promise().done(function () {
            wdwWid = $(window).width();
            wdwHei = $(window).height();

            //carrega loading
            loadingChat(wdwWid, wdwHei);
            setTimeout(function () {
                dismissLoadingChat();
                //messageWaterfall();
            }, 1000);

            var paddingChat = parseInt($('.panel-chat.redimensional-size').css('padding-top'));
            var headChat = $('.panel-chat.redimensional-size .chat-header').outerHeight();
            $('#chat').css('height', (topEleHei - headChat - paddingChat));

            $('.redimensional-size').css({
                'width': '100%'
            });

            $('.chat > div, .panel-enviadas').css('height', topEleHei);
        });
    } else {
        //Resize para �rea do usu�rio
        $('html').addClass('chat-general').promise().done(function () {
            wdwWid = $(window).width();
            wdwHei = $(window).height();

            //carrega loading
            loadingChat(wdwWid, wdwHei);
            setTimeout(function () {
                dismissLoadingChat()
                //messageWaterfall();
            }, 1000);

            var paddingChat = parseInt($('.panel-chat.redimensional-size').css('padding-top'));
            var headChat = $('.panel-chat.redimensional-size .chat-header').outerHeight();
            $('#chat').css('height', (topEleHei - headChat - paddingChat));

            $('.redimensional-size').width(wdwWid - sizeWidEnviadas - sizeWidDescricao);
            if (wdwWid > '764') {
                $('.chat > div').css('height', topEleHei).promise().done(function () {
                    chatInfoHei = $('.chat-descricao--info').outerHeight();
                    chatDescHei = $('.chat-descricao').outerHeight();
                    chatImgHei = $('.chat-descricao--img > img').outerHeight();
                    topElementsHei = chatDescHei - chatInfoHei;

                    chatImgDif = (chatDescHei - chatInfoHei - chatImgHei) / 2;
                    chatImgTop = 'auto';
                    if (chatImgDif < 0) {
                        chatImgTop = chatImgDif;
                    }
                    //console.log(chatImgDif);
                    $('.chat-descricao--img').css({
                        'height': topElementsHei
                    });
                    $('.chat-descricao--img > img').css({
                        'top': chatImgTop
                    });
                    //console.log('headChat:', headChat, 'topEleHei:', topEleHei, topEleHei - headChat - paddingChat);
                });
            } else {
                $('html, body').css({
                    'width': wdwWid,
                    'height': wdwHei,
                    'overflow': 'hidden'
                })
                heiEleMob = $('header.header').outerHeight();
                marginEleMob = parseInt($('header.header').css('margin-bottom'));
                heiDescHeader = $('.chat-descricao').outerHeight();
                heiChatHeader = $('.chat-header').outerHeight();
                heiBoxMsg = $('.box-type-msg').outerHeight();

                if (wdwHei > 450) {
                    midHei = wdwHei - (heiEleMob + heiDescHeader + heiChatHeader + marginEleMob + heiBoxMsg);
                } else {
                    $('.chat-descricao').hide();
                    $('.count-participantes').css({
                        'left': 'auto',
                        'right': '15px'
                    })
                    $('.chat-header').addClass('header-right');
                    $('.box-type-msg').css('height', '165px')
                    $('.box-type-msg .form-group, .box-type-msg .box-type-msg--action').addClass('minor-mobile')
                    midHei = wdwHei - (heiEleMob + marginEleMob + 165);
                }
                //console.log(heiEleMob, marginEleMob, heiDescHeader, heiChatHeader, heiBoxMsg, midHei);
                $('#chat').css({
                    'width': 'auto',
                    'height': midHei,
                    'max-width': 'inherit'
                });
                console.log('eu');
                var imgWid = $('.chat-descricao--img img').width();
                var imgHei = $('.chat-descricao--img img').height();
                if (imgWid > imgHei) {
                    $('.chat-descricao--img img').css({
                        'width': 'auto',
                        'height': '80px'
                    })
                }
            }
            //Se a tela for menor que 920 muda
            if (wdwWid < '920') { // && wdwWid > '764' && !wdwWid < '764'
                descricaoAct = $('.chat').find('.chat-descricao');
                enviadasAct = $('.panel-enviadas');
                panelChat = $('.chat').find('.panel-chat.redimensional-size');
                var widDesc = descricaoAct.outerWidth();
                var widEnv = enviadasAct.outerWidth();
                var widPanelChat = panelChat.outerWidth();
                widPanelChat = wdwWid - widDesc;
                enviadasAct.addClass('closed').css({
                    'right': '',
                    'overflow': 'hidden'
                });
                panelChat.attr('data-width', widPanelChat).css('width', widPanelChat - 50); //soma da barra + o a descricao
                //panelChat.css('width', widPanelChat) - 50; //soma da barra + o a descricao
                descricaoAct.attr('data-width', widDesc);

                //ajeita o footer
                $('.box-type-msg > .box-type-msg--info').hide();
                $('.box-type-msg > .box-type-msg--input.redimensional-size').css({
                    'width': widPanelChat,
                    'padding-left': '20px'
                });
            }
            if (wdwWid < '764') {
                console.log('mobilei');
                $('.panel-enviadas').css({
                    'height': wdwHei,
                    //'overflow-y': 'auto'
                })
            }
        });

        $('.panel-enviadas > .panel-body > .close').on('click', function (event) {
            event.preventDefault();
            wdwWid = $(window).width();
            wdwHei = $(window).height();
            if (wdwWid > '920') {
                enviadasAct = $(this).closest('.panel-enviadas');
                panelChat = $(this).closest('.chat').find('.panel-chat.redimensional-size');
                var widEnv = enviadasAct.outerWidth();
                var widPanelChat = panelChat.outerWidth();
                enviadasAct.addClass('closed').css({
                    'right': '',
                    'overflow': 'hidden'
                });
                panelChat.attr('data-width', widPanelChat).css('width', widPanelChat + widEnv - 50);
            } else if (wdwWid < '920' && wdwWid > '764') {
                descricaoAct = $(this).closest('.chat').find('.chat-descricao');
                enviadasAct = $(this).closest('.panel-enviadas');
                panelChat = $(this).closest('.chat').find('.panel-chat.redimensional-size');
                var widEnv = enviadasAct.outerWidth();
                var widPanelChat = panelChat.outerWidth();

                var dataDesc = descricaoAct.data('width');
                panelChat.removeClass('open');
                descricaoAct.removeClass('open');
                // descricaoAct.animate({
                //   'width': dataDesc
                // }, 350);
                enviadasAct.addClass('closed').css({
                    'right': '',
                    'overflow': 'hidden'
                });
            } else if (wdwWid < '764') {
                console.log('mobile');
                $(this).toggleClass('opened');
            }
            console.log(wdwWid);
        });
        $('.panel-enviadas > .panel-body > .more').on('click', function (event) {
            event.preventDefault();
            wdwWid = $(window).width();
            wdwHei = $(window).height();
            if (wdwWid > '920') {
                enviadasAct = $('.panel-enviadas');
                panelChat = $('.panel-chat.redimensional-size');
                //console.log(panelChat);
                console.log(panelChat.data('width'));
                var widEnv = enviadasAct.outerWidth();
                var widPanelChatOriginal = panelChat.data('width');
                panelChat.css('width', widPanelChatOriginal);
                enviadasAct.animate({
                    'right': 0,
                }, 250, function () {
                    enviadasAct.removeClass('closed').css('overflow', '');
                });
                //enviadasAct.removeClass('closed');
            } else if (wdwWid < '920' && wdwWid > '764') {
                enviadasAct = $('.panel-enviadas');
                descricaoAct = $('.chat-descricao');
                panelChat = $('.panel-chat.redimensional-size');
                //var widEnv = enviadasAct.outerWidth();
                var widPanelChatOriginal = panelChat.data('width');
                console.log(widPanelChatOriginal);
                panelChat.css('width', widPanelChatOriginal).addClass('open');
                descricaoAct.addClass('open');
                // descricaoAct.animate({
                //   'width': 0
                // }, 350);
                enviadasAct.animate({
                    'right': 0,
                }, 250, function () {
                    enviadasAct.removeClass('closed').css('overflow', '');
                });
            } else if (wdwWid < '764') {
                //console.log('mobile');
                $(this).closest('.panel-enviadas').toggleClass('opened closed');
                if ($('.panel-bg').length > 0) {
                    $('.panel-bg').toggle();
                } else {
                    $(this).closest('.panel-enviadas').parent().prepend('<div class="panel-bg"></div>');
                }
            }
            console.log(wdwWid);
        });
        //console.log(wdwWid);
    } // fim do resize para area do usuario

    //checa pra ver se tem que chamar fun��o de travar mensagem
    if ($('.box-type-msg').data('mask') == true) {
        maxMessages();
    }
}

function perguntaHeight() {
    if ($('.enviadas-msg--expand').length > 0) {
        $('.enviadas-msg--body').each(function (index, el) {
            var heiExpand = $(this).outerHeight();

            if (!$(this).hasClass('hd')) {
                if (heiExpand <= 60) {
                    $(this).closest('.enviadas-msg').addClass('full');
                    $(this).next('.enviadas-msg--expand').hide();
                } else {
                    $(this).attr('data-height', heiExpand).css('height', '60px');
                }
            }

            $(this).addClass('hd');
        });
    }
}

//chat
function resetChatResize() {
    //$('html').removeClass('chat-general');
    wdwWid = $(window).width();
    wdwHei = $(window).height();
    $('#chat, .redimensional-size, .chat-descricao--img, .chat-descricao--img > img, html, body, .chat-descricao, .count-participantes, .box-type-msg, .chat-descricao, .box-type-msg--info, .panel-enviadas, .box-max').removeAttr('style');
    $('.box-type-msg').find('.btn-default, .form-control').removeAttr('disabled');
    $('.chat-header').removeClass('header-right');
    $('.chat-descricao, .panel-chat').removeAttr('data-width');
    $('.enviadas-msg--body').removeAttr('data-height');
    $('.box-type-msg .form-group, .box-type-msg .box-type-msg--action').removeClass('minor-mobile');
    $('.panel-chat.redimensional-size').removeClass('open');
    $('.panel-bg').remove();
    $('.chat-descricao').removeClass('open');
    if (wdwWid > '920') {
        $('.panel-enviadas').removeClass('closed');
        $('.panel-enviadas').addClass('opened');
    } else if (wdwWid < '920' && wdwWid > '764') {
        $('.panel-enviadas').removeClass('closed');
        $('.panel-enviadas').addClass('opened');
    } else if (wdwWid < '764') {
        $('.panel-enviadas').removeClass('opened');
        $('.panel-enviadas').addClass('closed');
    }
}
//resizeCallback
function resizeCallback(callback) {
    resetChatResize();
    callback();
}
//loading chat
function loadingChat(wdwWid, wdwHei, message) {
    if (!$('.loader-wraper').length > 0) {
        $('body').append('<div class="loader-wraper" style="width: ' + wdwWid + 'px; height:' + wdwHei + 'px"><div class="loader"></div><div class="loader--message"></div></div>');
        var loaderHei = $('.loader').height();
        $('.loader, .loader--message').css('top', (wdwHei - loaderHei) / 3);
    } else {
        $('body > .loader-wraper').css({
            'width': wdwWid,
            'height': wdwHei
        });
        var loaderHei = $('.loader').height();
        $('.loader').css('top', (wdwHei - loaderHei) / 3);
    }
}
function dismissLoadingChat() {
    $('body > .loader-wraper').fadeOut('slow', function () {
        $(this).remove();
    });
}
function addMessage(message) {
    var loaderWpr = $('.loader-wraper .loader--message');
    if ($(loaderWpr).is(':visible')) {
        //showText(loaderWpr, message, 0, 20);
        loaderWpr.text(message).removeClass('opened').addClass('opened');
    } else {
        loaderWpr.text(message).addClass('opened');
    }

    function showText(target, message, index, interval) {
        if (index < message.length) {
            $(target).append(message[index++]);
            setTimeout(function () { showText(target, message, index, interval); }, interval);
        }
    }
}
// function messageWaterfall() {
//     addMessage('There is no spoon.');
//     dismissLoadingChat();
//
//     setTimeout(function () {
//         addMessage('Cypher: Ignorance is bliss.');
//
//         setTimeout(function () {
//             addMessage('Neo: Why do my eyes hurt?');
//
//             setTimeout(function () {
//                 addMessage('Morpheus: You\'ve never used them before.');
//
//                 setTimeout(function () {
//                     dismissLoadingChat()
//                 }, 2000);
//             }, 2000);
//
//         }, 2000);
//     }, 2000);
// }

function maxMessages(message) { //mensagem de exemplo: Voc� j� mandou <strong>5 perguntas</strong>. Aguarde uma ser respondida ou analisada para poder enviar novas.
    var boxTarget = $('.box-type-msg');
    var boxWid = boxTarget.outerWidth();
    var boxHei = boxTarget.outerHeight();
    var messageBox = message;
    var htmlToBox = '<div class="box-max"><div class="box-max--msg"><div class="loader-bar"></div>' + messageBox + '</div></div>';
    boxTarget.append(htmlToBox);
    boxTarget.find('.box-max').css({
        'width': boxWid,
        'height': boxHei
    }).addClass('opened');
    boxTarget.find('.btn-default, .form-control').attr('disabled', 'disabled');
}

function maxMessagesDismiss() {
    var boxTarget = $('.box-type-msg');
    boxTarget.find('.btn-default, .form-control').removeAttr('disabled');
    boxTarget.find('.box-max').removeClass('opened').queue(function () {
        $(this).remove().dequeue();
    });
}
