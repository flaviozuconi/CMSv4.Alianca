    $(document).ready(function () {

    $(".closebx").click(function () {

        $(this).parent().hide();

        //});

        $('.descripts .descrip').removeClass('active');



    });

    $(".circ").click(function () {

        variav = $(this).attr('class');
        //lastClass = variav.substring(variav.lastIndexOf(" ")+1);

        var mySplitResult = variav.split(" ");
        var lastClass = mySplitResult[mySplitResult.length - 3]





        $('.descripts .descrip').hide();
        $('.descripts .descrip').removeClass('active');

        $('.descripts').find('.' + lastClass).fadeIn("fast", function () {
            $(this).addClass('active');
        });

    });


    $(".altafxbaixo").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });



    $(".circ").mouseover(function () {

        $(this).addClass('notopac');
        $('.Row .circ').addClass('nowopa');

    });

    $(".circ").mouseleave(function () {

        $(this).removeClass('notopac');
        $('.Row .circ').removeClass('nowopa');

    });



    $(".mediofxbaixo").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });


    $(".baixofxbaixo").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });

    $(".irrelevantefxbaixo").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });

    $(".fade-info").mouseover(function () {

        $(this).hide();
        $('.box-prep').removeClass("active");
        $('.box-prep').find('.' + lastvardd).fadeOut("fast", function () {
            $('.box-prep').find('.' + lastvardd).removeClass("active");
        });

        $('.aviso').hide();
        $('.aviso2').hide();

    });


    $(".fade-info").click(function () {

        $(this).hide();


    });










    $(".minimofxstrenght").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });


    $(".baixofxstrenght").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });

    $(".mediofxstrenght").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });

    $(".fortefxstrenght").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });



    $(".aviso").mouseleave(function () {

        $('.box-prep').removeClass('active');
    });

    $(".aviso2").mouseleave(function () {

        $('.box-prep').removeClass('active');
    });




    $(".altafxlateral").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });

    $(".mediofxlateral").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });

    $(".baixofxlateral").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });



    });




    $(".irrelevantefxlateral").mouseover(function () {

        $('.fade-info').stop(true, true).fadeIn();

        vardd = $(this).attr('class');
        lastvardd = vardd.substring(vardd.lastIndexOf(" ") + 1);


        $('.box-prep').addClass('active');



        $('.box-prep').find('.' + lastvardd).fadeIn("fast", function () {
            $('.box-prep').find('.' + lastvardd).addClass("active");
        });

    });







    $(".BarraLateral ul li").click(function () {


        $('.BarraLateral ul li ul').stop(true, true).slideUp();
        $(this).find('ul').stop(true, true).slideDown();

    });




    $(".BarraLateral ul li ul li").mouseover(function () {
        exibcy = $(this).attr('class');

        $('.Row .circ').addClass('nowopa');
        $('.Row').find('.' + exibcy).addClass('notopac');
    });



    $(".BarraLateral ul li ul li").click(function () {
        //exibcy = $(this).attr('class');

        //$('.descripts .descrip').hide();
        $('.descripts .descrip').removeClass('active');

        //$('.descripts').find('.' + exibcy).fadeIn("fast", function() {
        $('.descripts').find('.' + exibcy).show();
        $('.descripts').find('.' + exibcy).addClass('active');
        //});
    });



    $(".BarraLateral ul li ul li").mouseleave(function () {


        $('.Row .circ').removeClass('nowopa');
        $('.Row').find('.' + exibcy).removeClass('notopac');
    });



    $(".c11").mouseover(function () {
        $('.inter11').stop(true, true).fadeIn();
    });
    $(".c11b").mouseover(function () {
        $('.inter11').stop(true, true).fadeIn();
    });


    $(".c11").mouseleave(function () {
        $('.inter11').stop(true, true).fadeOut();
    });

    $(".c11b").mouseleave(function () {
        $('.inter11').stop(true, true).fadeOut();
    });



    $(".c7").mouseover(function () {
        $('.inter7').stop(true, true).fadeIn();
    });
    $(".c7a").mouseover(function () {
        $('.inter7').stop(true, true).fadeIn();
    });


    $(".c7").mouseleave(function () {
        $('.inter7').stop(true, true).fadeOut();
    });

    $(".c7a").mouseleave(function () {
        $('.inter7').stop(true, true).fadeOut();
    });

    
    
});