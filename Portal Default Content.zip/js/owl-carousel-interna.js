// carousel historia
$(".owl-interna").owlCarousel({
	stagePadding: 100,
	items: 1,
	loop: false,
	center: true,
	merge:true
});
