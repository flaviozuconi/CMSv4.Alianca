/* Brazilian initialization for the jQuery UI date picker plugin. */
/* Written by Leonildo Costa Silva (leocsilva@gmail.com). */
(function (factory) {
    if (typeof define === 'function' && define.amd) {

        // AMD. Register as an anonymous module.
        define(['../datepicker'], factory);
    } else {

        // Browser globals
        factory(jQuery.datepicker);
    }
}(function (datepicker) {

    datepicker.regional['pt-BR'] = {
        closeText: 'Fechar',
        prevText: '&#x3C;Anterior',
        nextText: 'Próximo&#x3E;',
        currentText: 'Hoje',
        monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
        'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
        monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun',
        'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
        dayNames: ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'],
        dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'],
        dayNamesMin: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'],
        weekHeader: 'Sm',
        dateFormat: 'dd/mm/yy',
        firstDay: 0,
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: ''
    };
    datepicker.setDefaults(datepicker.regional['pt-BR']);

    return datepicker.regional['pt-BR'];

}));
//Reposiciona a direita o menu superior
function menuSupPosition(elTarget, elReference) {
    var wdtTarg = $(elTarget).outerWidth();
    var wdtRef = $(elReference).outerWidth();

    $(elTarget).each(function (event) {
        if ($(this).position().left > (wdtRef / 2) - wdtTarg) {
            $(this).find('.nav-content').addClass('right');
        }
    });
}
//Exibe o "vai pro topo"
function showGoTop(topTarget) {
    var topHeight = $(window).height();
    var targetHei = $(topTarget).outerHeight();
    if ($('.footer').length > 0) {
        var footerPos = $('.footer').offset().top;
        var footerMarg = $('.footer').css('margin-top');
        var footerMargP = parseInt(footerMarg);
    } else {
        var footerPos = 0;
        var footerMarg = 0;
        var footerMargP = 0;
    }

    $(window).scroll(function (event) {
        showTop = $(window).scrollTop();
        showBottom = showTop + topHeight + footerMargP + targetHei;
        //console.log(showTop, footerPos, showBottom, footerMargP, targetHei);

        if (showTop >= topHeight) {
            $(topTarget).fadeIn('slow');
        }
        else {
            $(topTarget).fadeOut('slow');
        }

        if (showBottom >= footerPos) {
            $(topTarget).addClass('fixo');
        }
        else {
            $(topTarget).removeClass('fixo');
        }
    });
}
function removeFocus(focusTar, parentTar) {
    $(focusTar).on('blur', function () {
        $(this).parents(parentTar).removeClass('open');
    });
}
function resizeMobile(tarRes) {
    var documentWid = $(window).width();
    $(tarRes).width(documentWid);
}
//Modificar a navegação por tabs para mobile - ficam flutuantes
function floatingTabs(tarFloatTabs) {
    $('.floating-tabs').height(
        $('.floating-tabs').children('li').outerHeight() * ($('.floating-tabs').children('li').length - 1)
    );

    $('.floating-tabs li.active').siblings().each(function () {
        $(this).css('top', $(this).position().top - 43);

        if ($(this).index() == 0) {
            $(this).css('top', 0);
        }
    }).promise().done(function () {
        $('.floating-tabs').addClass('absolute');
    });

    $('.floating-tabs [data-toggle="tab"]').on({
        'show.bs.tab': function (e) {
            eVar = $(e.target);
            cTop = eVar.parent().css('top')
            eVar2 = $(e.relatedTarget);

            eVar.parent().css('z-index', 12);
            eVar2.parent().css('top', cTop);
        },
        'shown.bs.tab': function (e) {
            eVar.parent().css('z-index', 10);
            eVar2.parent().css('z-index', 10);
        }
    });
}

//Menu superior fixo
function menuTopFunc() {
    if ($(window).scrollTop() > headSumHei) {
        $('.header').addClass('menu-fixed');
        $('main').addClass('menu-fixed-body');

        //Checa se a posição do menu é negativa
        if ($('.header.menu-fixed').css('top') == '-80px') {
            $('.header.menu-fixed').animate({
                top: 0
            }, 500);
        }
        /*if ($('.header').length > 0) {
            $('main').addClass('menu-fixed-body');
        }*/
        //Posiciona o menu no local correto
        if ($('.header').hasClass('menu-fixed')) {
            $('.header-menu-global').removeClass('active-menu');

            if (!$('.header .icon-menu').hasClass('in')) {
                $('.header .icon-menu').fadeIn('slow').addClass('in');
            }
            $('.header.menu-fixed .main-menu').removeClass('in');
        }
    }
        //Adiciona o menu quando não é rolagem. Refazer animação
    else {
        $('.header.menu-fixed').removeAttr('style').removeClass('menu-fixed').find('.main-menu').removeClass('in');
        $('main').removeClass('menu-fixed-body');
        $('.header .icon-menu').fadeOut('slow').removeClass('in');
    }
    $('.menu-global').find('.dropdown-menu').removeAttr('style');
    $('.search-top input').blur();
    //console.log($(window).scrollTop());
    if ($('[data-menu-fixed]').attr('data-menu-fixed') == "false") {
        $('main').removeClass('menu-fixed-body');
    }
};

//Loading - chamada
function channelingLoad(channelTarget) {
    chanEle = $(channelTarget);
    var getLoadSize = chanEle.attr('data-loading-target');
    var animate = chanEle.attr('data-loading-animate');
    var chWdt = chanEle.outerWidth();
    var chHei = chanEle.outerHeight();
    var chPos = chanEle.offset().top;
    var chHdrHei = $('header.menu-fixed').outerHeight();

    //Cheeca o tamanho da imagem, se o for NULL - DATA-LOADING-TARGET não definido - ele vai setar o tamanho pra
    //tela toda
    if (getLoadSize == null) {
        chWdt = $(window).width();
        chHei = $(window).height();
    }

    if (animate != null && animate) {
        $('html, body').animate({
            scrollTop: chPos - chHdrHei
        }, 1000);
    }

    loadSkin = channelTarget.attr('data-loading-skin');

    if (loadSkin == null) {
        loadSkin = 'spinner.gif';
    }
    if (loadSkin == 'dark') {
        loadSkin = 'spinner_dark.gif';
    }
    var contentSpinner = '<div class="spinner-wrap"><div class="sprite-spinner"><img src="/Portal/Braskem/img/' + loadSkin + '"></div></div>';

    //Checa se tem definição de target, se não tem ele vai fazer o loading carregar em cima da página inteira.
    //Se tiver o alvo (ELSE, não NULL) exibe o tamanho definido
    if (getLoadSize == null) {
        channelTarget.addClass('loading-spinner').append(contentSpinner);
        channelTarget.find('.spinner-wrap').addClass('loading-fixed');
    }
    else {
        channelTarget.addClass('loading-spinner').append(contentSpinner);
    }

    channelTarget.find('.spinner-wrap').fadeIn('slow').height(chHei).css('padding-top', (chHei - 54) / 2);
}
//Loading - saída
function doneLoad(channelTarget) {
    var targetToggleIn = channelTarget.find('[data-loading-togglein]'); //Pega o objeto que vai aparecer
    var targetToggleOut = channelTarget.find('[data-loading-toggleout]'); //Pega o objeto que vai sumir

    //Checa se os atributos DATA-LOADING-TOGGLEIN ou DATA-LOADING-TOGGLEOUT foram definidos.
    //Se voltarem 'vazios', qualquer um deles, ele remove somente o loading e deixa em aberto para ser inserido
    //onde quiser o elemento.
    if (targetToggleIn.length == 0 || targetToggleOut.length == 0) {
        var div = channelTarget.removeClass('loading-spinner').find('.spinner-wrap.loading-fixed');

        if (div.length == 0) {
            div = channelTarget.removeClass('loading-spinner').find('.spinner-wrap');
        }

        div.fadeOut().queue(function () {
            channelTarget.find('.spinner-wrap').remove().dequeue();
        });
    }
        //Se AMBOS existirem então ele vai esconder o elemento DATA-LOADING-TOGGLEOUT e exibiçãor o DATA-LOADING-TOGGLEIN
    else {
        channelTarget.find(targetToggleOut).slideUp().queue(function () {
            channelTarget.removeClass('loading-spinner').find('.spinner-wrap').fadeOut().done(function () {
                channelTarget.find('.spinner-wrap').remove();
            }).dequeue();
            this.remove();
        });
        channelTarget.find(targetToggleIn).fadeIn();
    }
}
//Identifica se o conteúdo do scroll é maior do que o viewport
function scrollizer(srcTarget, mediaType) {
    var srcHei = $(srcTarget).outerHeight();
    var wdwHei = $(window).height();
    var headMainHei = $('.main-header').outerHeight();

    var sizeComp;

    if (mediaType === 'mobile') {
        var headMainHei = $('.menu-mobile').outerHeight();
        var sizeComp = wdwHei - headMainHei - 30;
        //console.log(wdwHei, headMainHei, sizeComp)
    }
    else {
        var sizeComp = wdwHei - headMainHei - 30;
    }


    if (srcHei >= sizeComp) {
        $(srcTarget).height(sizeComp);
        $(srcTarget).mCustomScrollbar('destroy')
        $(srcTarget).mCustomScrollbar({
            scrollInertia: 300
        });
        //console.log('liga scrollizer');
    }
    else {
        $(srcTarget).mCustomScrollbar('destroy')
        $(srcTarget).removeAttr('style');
        //console.log('remove scrollizer');
    }
}

//Navegação por mapa
function braskemMap(identMap) {
    $('.braskem-map--leg > li').click(function (event) {
        var elPos = $(identMap).position().top;
        var elOff = $(identMap).offset().top;
        var unitsOff = $(identMap).find('.units').offset().top;
        var elPais = $(this).data('pais-target');
        var imgMap = $(identMap).find('figure');
        var sizeImg = imgMap.outerHeight();
        var posScroll = elOff;
        var wdwHei = $(window).outerHeight();
        var headMainHei = 80;//$('.main-header').outerHeight();
        var difScreen = wdwHei - headMainHei;


        console.log(
          'elPais: ' + elPais,
          'posScroll: ' + posScroll,
          'wdwHei: ' + wdwHei,
          'headMainHei: ' + headMainHei,
          'difScreen: ' + difScreen,
          'sizeImg: ' + sizeImg,
          'elPos: ' + elPos,
          'elOff: ' + elOff
        )

        if ($(window).width() > 991) {
            $('html, body').animate({ scrollTop: posScroll + headMainHei }, 1000);
        } else {
            var posScroll = $(identMap).find('.units').offset().top;
            var headMainHei = $('.menu-mobile').outerHeight();
            $('html, body').animate({ scrollTop: posScroll - headMainHei - 30 }, 1000, function () {
                if (document.createEvent) {
                    window.dispatchEvent(new Event('resize'));
                } else {
                    document.body.fireEvent('onresize');
                }
            });
        }

        if ($('[data-pais]').hasClass('in')) {
            $('[data-pais].in').fadeOut().removeClass('in').promise().done(function () {
                $(identMap).find('[data-pais="' + elPais + '"]').slideDown(1000).addClass('in');
            });
        }
        else {
            $(identMap).find('[data-pais="' + elPais + '"]').slideDown(1000).addClass('in');
        }
    });

    if ($(window).width() < 992) {
        $('.braskem-map--leg li').popover('show');
        $('.braskem-map--leg .popover').bind('click');
        $('.braskem-map--leg .popover').click(function () {
            var popId = $(this).attr('id');
            $('[aria-describedby="' + popId + '"').trigger('click');
        });
    }
}

//Build mobile Menu
function mobileMenuBdr() {
    $('[data-subcall]').click(function () {
        var dataCall = $(this).data('subcall');
        var tarElem = $(this).parents('.menu-mobile').find('[data-subtarget="' + dataCall + '"]');

        $(this).parents('.menu-mobile--calls').find('li').removeClass('open');
        $(this).parents('.menu-mobile').find('[data-subtarget]').fadeOut();

        if ($(tarElem).is(':hidden')) {
            //console.log(dataCall);
            $(this).addClass('open');

            if (dataCall === 'sub-messages') {
                //console.log('messages');
                $(tarElem).slideDown(function () {
                    var scr = scrollizer('.sub-messages > .message-box--list', 'mobile');
                    scr;
                });
            }
            else {
                $(tarElem).slideDown();
            }
        }
    });

    $('[data-toggle="offcanvas"]').click(function () {
        $('.sidebar-offcanvas').toggleClass('in');
        $('body').toggleClass('offcanvas-body');
        $(this).parents('.menu-mobile').find('[data-subtarget]').fadeOut();
    });

    $('[data-toggle="submenu"] .dropdown > span').click(function (event) {
        $(this).siblings('.nav-content').slideToggle();
    });
}
//monta aviso no mobile
function avisoMount() {
    var contentAviso = $('.main-header').find('.message-box--list').html();
    var qtdAviso = $('.main-header .message-box').find('i').text();

    $('.sub-messages > .message-box--list').html(contentAviso);
    $('.menu-mobile--calls .message-box').find('i').text(qtdAviso);
}

//Faz paginação de lista > http://jsfiddle.net/fernandob/uz2nv00a/
function showList(elShowList, listItems, targetList, listCount, listButtonText, listCountDisplay) {
    var elShowList;
    var listCount;
    var listSize;
    var listCountDisplay;

    if (elShowList === undefined || elShowList === null || elShowList === '') {
        elShowList = $(document).find('[data-list]');
    }

    var listItems = elShowList.data('list-items');
    if (listItems === undefined || listItems === null || listItems === '') {
        visibleItems = 3;
    } else {
        visibleItems = listItems;
    }

    if (targetList === undefined || targetList === null || targetList === '') {
        targetList = $('[data-list-target]');
        listSize = targetList.length;
    } else {
        listSize = targetList.length;
    }

    if (listCount === undefined || listCount === null || listCount === '') {
        count = 0;
    } else {
        count = elShowList.data('list-count');
    }

    var listButtonText = elShowList.data('list-btn-text');
    if (listButtonText === undefined || listButtonText === null || listButtonText === '') {
        listButtonText = 'Ver mais';
    } else {
        listButtonText = elShowList.data('list-btn-text');
    }

    listCountDisplay = elShowList.data('list-display');
    if (listCountDisplay === undefined || listCountDisplay === null || listCountDisplay === '') {
        listCountDisplay = "false";
    }

    targetList.each(function (index, el) {
        if (index % visibleItems == 0) {
            count++;
        }
        $(this).attr('data-count', count);

        if ($(this).data('count') == 1) {
            $(this).fadeIn('slow', function () {
                $('.btn-list').fadeIn('slow');
            });
        }
    });

    if (listCountDisplay === true) {
        elShowList.after('<button class="btn btn-default btn-block btn-list mgutter-h-lg">' + listButtonText + ' <em><span class="vagas--qtd">' + visibleItems + '</span> de <span class="vagas--total">' + listSize + '</span></em>' + '</button>');
    }
    else {
        elShowList.after('<button class="btn btn-default btn-block btn-list mgutter-h-lg">' + listButtonText + '</button>');
    }


    var countNew = $(targetList).data('count');

    $('.btn-list').on('click', function (e) {
        e.preventDefault();
        _this = $(this);

        var countVisi = $('[data-list-target]:visible').length;
        if (countVisi + visibleItems <= listSize) {
            $(this).find('.vagas--qtd').text(countVisi + visibleItems);
        }
        else {
            $(this).find('.vagas--qtd').text(countVisi);
        }

        console.log(countVisi);

        countNew = countNew + 1;
        $(elShowList).find('[data-count=' + countNew + ']').slideDown();

        var x = listSize % (countNew);

        if (listSize <= (countNew) * visibleItems) {
            $(this).fadeOut();
        }
    });
}

function querystring(key) {
    var re = new RegExp('(?:\\?|&)' + key + '=(.*?)(?=&|$)', 'gi');
    var r = [], m;
    while ((m = re.exec(document.location.search)) != null) r[r.length] = m[1];
    return r;
}

//chat
function chatResize() {
    var sizeWidEnviadas = $('.panel-enviadas').outerWidth();
    var sizeWidDescricao = $('.chat-descricao').outerWidth();
    var sizeHeiTools = $('.box-type-msg').outerHeight();
    var sizeHeiHeader = $('.main-header__chat').outerHeight();
    var wdwWid = $(window).width();
    var wdwHei = $(window).height();

    $('html').addClass('chat-general').promise().done(function () {
        wdwWid = $(window).width();
        wdwHei = $(window).height();
        $('body').append('<div class="loader-wraper" style="width: ' + wdwWid + 'px; height:' + wdwHei + 'px"><div class="loader"></div></div>');
        setTimeout(function () {
            $('body > .loader-wraper').fadeOut('slow', function () {
                $(this).remove();
            });
        }, 3000);
        var paddingChat = parseInt($('.panel-chat.redimensional-size').css('padding-top'));
        var headChat = $('.panel-chat.redimensional-size .chat-header').outerHeight();
        $('.redimensional-size').width(wdwWid - sizeWidEnviadas - sizeWidDescricao);
        $('.chat > div').css('height', wdwHei - sizeHeiTools - sizeHeiHeader).promise().done(function () {
            chatInfoHei = $('.chat-descricao--info').outerHeight();
            chatDescHei = $('.chat-descricao').outerHeight();
            chatImgHei = $('.chat-descricao--img > img').outerHeight();

            chatImgDif = (chatDescHei - chatInfoHei - chatImgHei) / 2;
            chatImgTop = 'auto';
            if (chatImgDif < 0) {
                chatImgTop = chatImgDif;
            }
            //console.log(chatImgDif);
            $('.chat-descricao--img').css({
                'height': chatDescHei - chatInfoHei
            });
            $('.chat-descricao--img > img').css({
                'top': chatImgTop
            });
        });
        $('#chat').css('height', (wdwHei - sizeHeiTools - paddingChat - headChat));
    });

    $('.panel-enviadas > .panel-body > .close').on('click', function (event) {
        event.preventDefault();
        if (wdwWid > '920') {
            enviadasAct = $(this).closest('.panel-enviadas');
            panelChat = $(this).closest('.chat').find('.panel-chat.redimensional-size');
            var widEnv = enviadasAct.outerWidth();
            var widPanelChat = panelChat.outerWidth();
            enviadasAct.addClass('closed').css({
                'right': '',
                'overflow': 'hidden'
            });
            panelChat.attr('data-width', widPanelChat).css('width', widPanelChat + widEnv - 50);
        }
    });
    $('.panel-enviadas > .panel-body > .more').on('click', function (event) {
        event.preventDefault();
        if (wdwWid > '920') {
            enviadasAct = $(this).closest('.panel-enviadas');
            panelChat = $(this).closest('.chat').find('.panel-chat.redimensional-size');
            var widEnv = enviadasAct.outerWidth();
            var widPanelChatOriginal = panelChat.data('width');
            panelChat.css('width', widPanelChatOriginal);
            enviadasAct.animate({
                'right': 0,
            }, 250, function () {
                enviadasAct.removeClass('closed').css('overflow', '');
            });
            //enviadasAct.removeClass('closed');
        }
    });
    console.log(wdwWid);
    if (wdwWid < '920') {
        enviadasAct = $('.panel-enviadas');
        panelChat = $('.chat').find('.panel-chat.redimensional-size');
        var widEnv = enviadasAct.outerWidth();
        var widPanelChat = panelChat.outerWidth();
        enviadasAct.addClass('closed').css({
            'right': '',
            'overflow': 'hidden'
        });
        panelChat.attr('data-width', widPanelChat).css('width', wdwWid - 350); //soma da barra + o a descricao
    }
}
