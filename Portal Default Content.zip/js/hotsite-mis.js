$(document).ready(function () {
  $(document).on('scroll', function () {
    menuFixed();
  });
  $('#mis-menu').on('show.bs.collapse', function(){
    $('html, body').addClass('opened-menu');
  });
  $('#mis-menu').on('hide.bs.collapse', function(){
    $('html, body').removeClass('opened-menu');
  });

  $('.carousel-videos').owlCarousel({
    items: 1
  });

  $('.main-carousel').owlCarousel({
    items: 1,
    animateIn: 'fadeIn',
    animateOut: 'fadeOut'
  });
  $('.main-carousel').on('changed.owl.carousel', function(event) {
    var _this = $(this);
    _this.addClass('transit');

    setTimeout(function(){
      _this.removeClass('transit');
    }, 1000);
  });


  //Atribue modal para lighbox
/*  $(document).delegate('*[data-toggle="lightbox"]', 'click', function (event) {
      event.preventDefault();
      $(this).ekkoLightbox();
  });*/

  $(document).delegate('*[data-toggle="linkbox"]', 'click', function(event) {
      event.preventDefault();
      $(this).ekkoLightbox();
  });

  $('[data-toggle="lightbox"]').on('click', function(event) {
      var albumTarget = $(this).data('gallery');
      console.log("aa", albumTarget);

      numeroFotos = $(this).parents('.box-part').find('[data-gallery="'+albumTarget+'"]').length;
      console.log("ab", numeroFotos);

      var ekkoIndex = $(this).index('[data-gallery="'+albumTarget+'"]');
      console.log(ekkoIndex+1);

      ekkoIndexAtual = ekkoIndex+1;

      var ekkoTotal = ekkoCountChange(numeroFotos, ekkoIndexAtual);
      console.log("ac", ekkoTotal);
  });
  $(document).delegate('*[data-gallery*="navigateTo-"]', 'click', function (event) {
      event.preventDefault();
      return $(this).ekkoLightbox({
          onShown: function () {

              var lb = this;
              $(lb.modal_content).on('click', '.controler-pointer span>a', function(e) {
                  e.preventDefault();
                  navIndex = $(this).parent().index();
                  lb.navigateTo(navIndex);
                  ekkoCountChange(numeroFotos, navIndex);
                  consol.log('shown1');
              });

              console.log('gal SHOW');
              ekkoCount(numeroFotos, ekkoIndexAtual);

                if (window.console) {
                    //return console.log('Checking our the events huh?');
                    var modal = this.modal_content;
                    var modalw = $('.modal-loading').parent(); //watch element modification
                    //console.log(this.modal_content.attr('class'));

                    $(modalw).bind('DOMSubtreeModified', function (e) {
                        if (e.target.innerHTML.length > 0) {
                            setTimeout(function () {
                                $('.modal-footer').show();
                            }, 100);
                        }
                    });
                }
          },
          onNavigate: function (direction, itemIndex) {
              // if (window.console) {
              //     return console.log('Navigating ' + direction + '. Current item: ' + itemIndex);
              // }
              ekkoCountChange(numeroFotos, itemIndex);
              console.log('navigate');
          }
      });
          console.log('gal RETURAN');
  });
  $('.ekko-lightbox').on('shown.bs.modal', function(e) {
      console.log('poxa');

      var albumTarget = $(this).data('gallery');
      var numeroFotos = $(this).parents('.gallery-lightbox').find('[data-gallery="'+albumTarget+'"]').length;
  });
});

function menuFixed() {
  if ($(window).scrollTop() > 150) {
    $('.header').addClass('menu-fixed');
    $('body').addClass('menu-afixed');
  } else {
    $('.header').removeClass('menu-fixed');
    $('body').removeClass('menu-afixed');
  }
}

function ekkoCount(numeroFotos, ekkoIndexAtual) {
    var itemIndex = ekkoIndexAtual;
    var tarEkko = $('.ekko-lightbox .modal-header .counter');
    var tarPointer = $('.ekko-lightbox .modal-body .controler-pointer');
    //$('.ekko-lightbox .modal-header').find('.counter').remove();
    //$('.ekko-lightbox .modal-header').append('<div class="pull-right counter"></div>');
    if (!tarEkko.hasClass('opened')) {
        tarEkko.addClass('opened');
        tarEkko.find('.active').html(itemIndex);
        tarEkko.find('.total').html(numeroFotos);

        for (var i = 1; i <= numeroFotos; i++) {
            //console.log(i);
            if (i == itemIndex) {
                tarPointer.append('<span class="active item-'+i+'"><a href="#"></a></span>');
            }
            else {
                tarPointer.append('<span class="item-'+i+'"><a href="#"></a></span>');
            }
        }

        if(numeroFotos > 1) {
          $('.ekko-lightbox .modal-header .counter').removeClass('hide');
        }
    }
    else {
        tarEkko.find('.active').html(itemIndex);
        tarEkko.find('.total').html(numeroFotos);
        tarEkko.removeClass('opened');

        for (var i = 1; i <= numeroFotos; i++) {
            //console.log(i);
            if (i == itemIndex) {
                tarPointer.append('<span class="active item-'+i+'"><a href="#"></a></span>');
            }
            else {
                tarPointer.append('<span class="item-'+i+'"><a href="#"></a></span>');
            }
        }
    }
    console.log('ekkoCount');
}
function ekkoCountChange(numeroFotos, itemIndex) {
    var numb = itemIndex+1;
    var tarPointer = $('.ekko-lightbox .modal-body .controler-pointer');

    $('.ekko-lightbox .modal-header .counter').find('.active').html(numb);

    tarPointer.children('span').removeClass('active');
    tarPointer.find('.item-'+numb).addClass('active');

    console.log('ekkoCountChange');
}
function ekkoCountED() {
    var numeroDivs = $( ".ekko-lightbox-container div" ).length;
    var ekko = $('.ekko-lightbox');

    $('.ekko-lightbox .counter .total').append(numeroDivs);
    $('.ekko-lightbox .modal-body').append('<div class="controler-pointer"></div>').promise().done(function() {
        for (var i = 1; i <= numeroDivs; i++) {
            console.log(i);
            ekko.find('.controler-pointer').append('<span class="item-'+i+'"><a href="#"></a></span>');
        }
    });
    console.log('ekkoCountED');
}