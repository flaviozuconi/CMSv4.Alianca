$(document).ready(function() {

  var owl = $('.mol-midia--carousel');

  $.when(wrapElements(4)).then(function () {
    owl.owlCarousel({
      items: 1,
      nav: false,
      onInitialized: getCount(owl)
    });
  });
  owl.on('changed.owl.carousel', function(event) {
    changeCount(event);
  });

  $('.mol-midia .btn-prev').click(function() {
    owl.trigger('prev.owl.carousel');
  });
  $('.mol-midia .btn-next').click(function() {
    owl.trigger('next.owl.carousel');
  });
  $('.mol-midia--controls--paginate a').click(function() {
    event.preventDefault();
    var _that = $(this).parent('li').index();
    owl.trigger('to.owl.carousel', _that);
  });

  $('.mol-midia--carousel .post-box-left > figure > img').each(function(index, el) {
    var widFig = $(this).width();
    var heiFig = $(this).height();

    if (widFig > heiFig) {
      $(this).addClass('img__horiz');
    } else {
      $(this).addClass('img__verti');
    }
  });

  $('.mol-midia--carousel .post-box-left h3').each(function(index, el) {
    var valRep = $(this);
    var msgRep = '(...)';
    replaceText(valRep, 36, msgRep);
  });
  $('.mol-midia--carousel .post-box-left p').each(function(index, el) {
    var valRep = $(this);
    var msgRep = '...';
    replaceText(valRep, 54, msgRep);
  });

});

function wrapElements(elCount){
  var elCount = elCount;
  var divs = $('.mol-midia--carousel .news-post');
  for(var i = 0; i < divs.length; i+=elCount) {
    divs.slice(i, i+elCount).wrapAll('<div class="item"></div>');
  }
}
function replaceText(valRep, sizeRep, msgRep) {
  var elem = valRep.text();
  var size = sizeRep;

  if (elem.length > size) {
    var textProc = elem.substr(0, size) + ' ' + msgRep;
    valRep.text(textProc);
  }
}
function changeCount(event) {
  var items = event.item.count;
  var page = event.page.index;     // Position of the current page
  var size = event.page.size;      // Number of items per page
  console.log(items, page, size);

  if (page+1 > 3 && page+1 < items) {
    $('.mol-midia--controls--paginate li').removeClass('active');
    $('.mol-midia--controls--paginate li span').text(page+1).parent().addClass('active');
    console.log(page+1, items);
  } else {
    $('.mol-midia--controls--paginate li span').text('...');

    if (page+1 < items) {
      $('.mol-midia--controls--paginate li').removeClass('active').eq(page).addClass('active');
    } else {
      $('.mol-midia--controls--paginate li').removeClass('active').last().addClass('active');
    }
  }

  if (page+1 == items) {
    $('.mol-midia .btn-prev').removeClass('inactive');
    $('.mol-midia .btn-next').addClass('inactive');
    console.log('ultima')
  } else if (page+1 == 1) {
    $('.mol-midia .btn-next').removeClass('inactive');
    $('.mol-midia .btn-prev').addClass('inactive');
    console.log('primeira')
  } else {
    $('.mol-midia .btn-control').removeClass('inactive');
  }

}
function getCount(owl) {
  // Provided by the core
  var count = owl.find('.item').length;
  var page = owl.find('.item').index() + 1;
  var widCont = $('.mol-midia--controls').outerWidth();
  var widBtn = $('.btn-next').outerWidth();
  //console.log(count, page);

  i = 1;
  owl.find('.item').each(function(index, el) {
    if (widCont-(widBtn*2) < widBtn*count) {
      console.log('botoes maiores', widCont, widBtn*count, count);
      if (i <= 3) {
        $('.mol-midia--controls--paginate').append('<li><a href="#">'+i+'</a></li>');
      } else if (i == count) {
        $('.mol-midia--controls--paginate').append('<li><span>...</span></li><li><a href="#">'+i+'</a></li>');
      }
    } else {
      $('.mol-midia--controls--paginate').append('<li><a href="#">'+i+'</a></li>');
    }
    $('.mol-midia--controls--paginate li:first').addClass('active');
    $('.mol-midia .btn-prev').addClass('inactive');
    i++;
  });

}
