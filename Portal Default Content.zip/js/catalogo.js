$(document).ready(function () {
    //vars gerais
    var respWdt = 768;
    var pageAtual;
    var targetFlip = $('.flipbook');
    var contentFlip;
    var documentWid;
    var documentHei;
    var wdwWid;
    var wdwHei;
    var pageAtual;
    var catalogoDetalhe = $('.catalogo--detalhe');

    //for mobile
    // Listen for orientation changes
    window.addEventListener('orientationchange', function () {
        // Announce the new orientation number
        //console.log(screen.orientation);
        //chama a função
    }, false);

    // Listen for resize changes
    window.addEventListener('resize', function (e) {
        // Get screen size (inner/outerWidth, inner/outerHeight)
        wdwWid = $(window).width();
        wdwHei = $(window).height();
        //console.log(wdwWid, wdwHei);
        //chama a função
        if (!catalogoDetalhe.hasClass('opened')) {
            catalogoDetalhe.addClass('opened');
            if (catalogoDetalhe.is(':visible')) {
                //$('.catalogo--detalhe .catalogo--close').trigger('click');
                console.log('in fecha');
                //catalogoDetalhe.removeClass('in');
            } else {
                console.log('in abre');
                //catalogoDetalhe.removeClass('in');
            }
        }

    }, false);

    //isMobile
    if (isMobile.phone || isMobile.tablet) {

    } else {

    }

    $('.catalogo--categorias--box').on('click', function (event) {
        event.preventDefault();
        /* Act on the event */
    });

    $('.catalogo--caller').on('click', function () {
        documentWid = $(document).width();
        documentHei = $(document).height();
        wdwWid = $(window).width();
        wdwHei = $(window).height();
        contentFlip = targetFlip.html();
        pageAtual = 1;
        //console.log(contentFlip);

        //Exibe o conteúdo do catálogo e faz os cálculos todos de exibição
        loadingCatalogoModal(targetFlip, documentWid, documentHei, wdwWid, wdwHei, contentFlip, pageAtual, catalogoDetalhe);

    });

    $(document).on('keydown', function (e) {
        if (e.keyCode === 27) { // ESC
            closeCatalogoModal(targetFlip, contentFlip, catalogoDetalhe);
        }
    });

    targetFlip = $('.flipbook');
    catalogoDetalhe = $('.catalogo--detalhe');

    $('.catalogo--detalhe .catalogo--close, .catalogo--detalhe .close--brand').on('click', function (e) {
        e.preventDefault();
        /* Act on the event */
        closeCatalogoModal(targetFlip, contentFlip, catalogoDetalhe);
    });
    $('.flip-controls .prev, .pagination-leitor .prev, .catalogo--zoom .ul-controls .prev').on('click', function (e) {
        e.preventDefault();
        targetFlip.turn('previous');
        //pageAtiva = targetFlip.turn('page');
        //targetFlip.turn('page', pageAtiva - 2);
    });
    $('.flip-controls .next, .pagination-leitor .next, .catalogo--zoom .ul-controls .next').on('click', function (e) {
        e.preventDefault();
        targetFlip.turn('next');
        //pageAtiva = targetFlip.turn('page');
        //targetFlip.turn('page', pageAtiva + 2);
    });

    $('.close--zoom').on('click', function (e) {
        e.preventDefault();
        closeZoom(targetFlip);
    });

    //owl-carousel-catalogo
    if ($('#owl-sync-detalhes').length > 0) {
        var syncDetalhes = $('#owl-sync-detalhes');
        var syncThumbs = $('#owl-sync-thumbs');

        syncDetalhes.owlCarousel({
            items: 1,
            nav: true,
            dots: true,
            pagination: false,
            navText: ["<span class='glyphicon glyphicon-menu-left'></span>", "<span class='glyphicon glyphicon-menu-right'></span>"],
        });

        syncThumbs.owlCarousel({
            items: 7,
            dots: true,
            onInitialized: syncedFirstChild,
        });

        // variáveis global
        var qtdItens = $('.owl-item', syncThumbs).length;

        // callbacks custom
        $('.owl-item').on('click', function () {
            indexItem($(this).index())
        });

        $('.owl-next').on('click', function () {
            var atual = $('.synced', syncThumbs).index();
            var nth = atual + 2;
            if (nth <= qtdItens) {
                $(".owl-item", syncThumbs).removeClass('synced');
                $(".owl-item:nth-child(" + nth + ")", syncThumbs).addClass('synced');
            }
        });

        $('.owl-prev').on('click', function () {
            var atual = $('.synced', syncThumbs).index();
            if (atual > 0) {
                $(".owl-item", syncThumbs).removeClass('synced');
                $(".owl-item:nth-child(" + atual + ")", syncThumbs).addClass('synced');
            }
        });

        // callbacks
        function syncedFirstChild() {
            $(".owl-item:first-child", syncThumbs).addClass('synced');
        }

        function indexItem(e) {
            event.preventDefault();
            syncDetalhes.trigger('to.owl.carousel', e);
            $(".owl-item", syncThumbs).removeClass('synced');
            var nth = e + 1;
            $(".owl-item:nth-child(" + nth + ")", syncThumbs).addClass('synced');
        }
    }
});


//loading chat
function loadingCatalogo(wdwWid, wdwHei, content) {
    if (!$('.loader-wraper').length > 0) {
        $('body').append('<div class="loader-wraper" style="width: ' + wdwWid + 'px; height:' + wdwHei + 'px"><div class="loader-ie9"><img src="img/spiffygif_90x90.gif"></div><div class="loader"></div><div class="loader--message"></div></div>');
        var loaderHei = $('.loader').height();
        $('.loader-wraper').slideDown(function () {
            content.addClass('in');
        });
        $('.loader, .loader--message').css('top', (wdwHei - loaderHei) / 3);
    } else {
        $('body > .loader-wraper').css({
            'width': wdwWid,
            'height': wdwHei
        });
        var loaderHei = $('.loader').height();
        $('.loader').css('top', (wdwHei - loaderHei) / 3);
    }
}
function dismissLoadingCatalogo() {
    $('body > .loader-wraper').fadeOut('slow', function () {
        $(this).remove();
    });
}
function closeZoom(targetFlip) {
    $('.catalogo--zoom').fadeOut(function () {
        if (targetFlip.length > 0) {
            //console.log(targetFlip);
            targetFlip.turn('zoom', 1);
            $('.draggable').draggable('destroy');
            targetFlip.css({
                'left': 0,
                'top': 0
            }).parent().removeClass('dragging');
        }
        if ($('.leitor-catalogo').length > 0) {
            $('.leitor-catalogo').removeClass('fullpage');
        }
    });
}
function closeCatalogoModal(targetFlip, contentFlip, catalogoDetalhe) {
    $('body').removeClass('stop-scrolling');
    //console.log(targetFlip);
    //remove zoom
    if (targetFlip.hasClass('ui-draggable')) {
        //console.log(targetFlip);
        closeZoom(targetFlip);
    }
    catalogoDetalhe.removeClass('opened').slideUp(function () {
        targetFlip.turn('destroy').promise().done(function () {
            targetFlip.html(contentFlip).removeAttr('style');
            //console.log(contentFlip);
        });
        $(this).removeClass('in');
        //pageAtual = 1;
    });
}

function loadingCatalogoModal(targetFlip, documentWid, documentHei, wdwWid, wdwHei, contentFlip, pageAtual, catalogoDetalhe) {

    if (isMobile.phone || isMobile.tablet) {        
        return false;
    }


    catalogoDetalhe.fadeIn().promise().done(function () {
        footerHei = $('.controls-bar').outerHeight();
        bodyHei = wdwHei - footerHei;
        padHeiBody = bodyHei / 80;
        heiImg = bodyHei - (padHeiBody * 2);
        widReal = 510;
        heiReal = 715;
        widTotalImg = ((heiImg * widReal) / heiReal) * 2;
        _that = $(this);

        //console.log(widTotalImg, heiImg, padHeiBody)
        loadingCatalogo(wdwWid, wdwHei, _that);

        targetFlip.css({
            width: widTotalImg,
            height: heiImg,
            'margin-top': padHeiBody,
            'margin-bottom': padHeiBody
        });
        $('.flip-controls .btn-flip-controls').height(bodyHei);

        var medidaDif = (wdwWid - widTotalImg) / 2;
        //console.log(medidaDif/2);
        $('.flip-controls .prev').css('left', medidaDif - 30);
        $('.flip-controls .next').css('right', medidaDif - 30);

        //Inicia o turn
        if (!$('.flipbook .page-wrapper').lenght > 0) {
            targetFlip.fadeIn(function () {

                setTimeout(function () {
                    dismissLoadingCatalogo();
                    targetFlip.turn({
                        //page: 1
                    });
                }, 2000);
            })
        }
        var qtdPages = $('.flipbook > div').length;
        //console.log(qtdPages);
        pageAtual = 1;

        // controle de flipages
        $('.total').text(qtdPages);
        $('.atual').text(pageAtual);

        $('.zoom--caller').on('click', function (e) {
            e.preventDefault();
            $('.catalogo--zoom').fadeIn(function () {
                $('.leitor-catalogo').addClass('fullpage');
                $('.flipbook').addClass('draggable').parent().addClass('dragging');
                $('.draggable').draggable();
                targetFlip.turn('zoom', 2);
            });
        });

        $('body').addClass('stop-scrolling');

        var zoom = $('.catalogo--zoom--input').slider();
        zoom.on('slide', function (e) {
            targetFlip.turn('zoom', e.value);
        });
        targetFlip.bind('turn', function (event, page, view) {
            $('.atual').text(page);
        });
        catalogoDetalhe.removeClass('opened');
    });
}
